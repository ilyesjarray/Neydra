#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
                    GLOBAL NEYDRA NEWS
================================================================================
        Revolutionary 3D Earth News Visualization System
                  "NASA x AL JAZEERA x NEYDRA"
================================================================================
"""

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import asyncio
import json
import re
import hashlib
import random
import feedparser
from urllib.parse import quote
import html
import os

try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

# ============================================================================
#                         SYSTEM CONFIGURATION
# ============================================================================

SYSTEM_NAME = "GLOBAL NEYDRA NEWS"
VERSION = "3.0.0"
SUBTITLE = "NASA x AL JAZEERA x NEYDRA"

# COMPREHENSIVE RSS Feed Sources
RSS_FEEDS = {
    "world": [
        "https://www.aljazeera.com/xml/rss/all.xml",
        "https://feeds.bbci.co.uk/news/world/rss.xml",
        "http://rss.cnn.com/rss/edition_world.rss",
        "https://www.reuters.com/rssFeed/worldNews",
        "https://rss.nytimes.com/services/xml/rss/nyt/World.xml",
        "https://www.theguardian.com/world/rss",
        "https://www.france24.com/en/rss",
        "https://www.dw.com/en/rss/s-1001",
        "https://news.un.org/feed/subscribe/en/news/region/world/feed/rss.xml",
        "https://feeds.npr.org/1004/rss.xml",
        "https://apnews.com/rss/apf-topnews",
        "https://feeds.washingtonpost.com/rss/world",
    ],
    "technology": [
        "https://feeds.feedburner.com/TechCrunch",
        "https://www.wired.com/feed/rss",
        "https://arstechnica.com/feed/",
        "https://feeds.bbci.co.uk/news/technology/rss.xml",
        "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml",
        "https://www.theverge.com/rss/index.xml",
        "https://feeds.npr.org/1019/rss.xml",
        "https://www.engadget.com/rss.xml",
    ],
    "business": [
        "https://feeds.bbci.co.uk/news/business/rss.xml",
        "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml",
        "https://www.reuters.com/rssFeed/businessNews",
        "https://www.ft.com/rss/world",
        "https://www.cnbc.com/id/10000664/device/rss/rss.html",
    ],
    "science": [
        "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml",
        "https://rss.nytimes.com/services/xml/rss/nyt/Science.xml",
        "https://www.nature.com/feeds/news_and_opinion.rss",
        "https://www.sciencedaily.com/rss/all.xml",
        "https://feeds.npr.org/1007/rss.xml",
        "https://www.scientificamerican.com/rss",
    ],
    "health": [
        "https://feeds.bbci.co.uk/news/health/rss.xml",
        "https://rss.nytimes.com/services/xml/rss/nyt/Health.xml",
        "https://feeds.npr.org/1128/rss.xml",
        "https://www.medicalnewstoday.com/rss",
    ],
    "politics": [
        "https://feeds.bbci.co.uk/news/politics/rss.xml",
        "https://rss.nytimes.com/services/xml/rss/nyt/Politics.xml",
        "http://rss.cnn.com/rss/cnn_allpolitics.rss",
        "https://www.politico.com/rss/politicopicks.xml",
        "https://feeds.washingtonpost.com/rss/politics",
    ],
    "sports": [
        "https://feeds.bbci.co.uk/sport/rss.xml",
        "http://rss.cnn.com/rss/edition_sport.rss",
        "https://rss.nytimes.com/services/xml/rss/nyt/Sports.xml",
        "https://www.espn.com/espn/rss/news",
        "https://www.skysports.com/rss/12040",
    ]
}

# Country coordinates (Abbreviated for brevity, ensure this dict is complete in your actual file)
COUNTRY_COORDS = {
    "united states": {"lat": 38.0, "lon": -97.0, "code": "US"},
    "usa": {"lat": 38.0, "lon": -97.0, "code": "US"},
    # ... (Include full list from your provided code here) ...
    "china": {"lat": 35.0, "lon": 105.0, "code": "CN"},
    "russia": {"lat": 60.0, "lon": 100.0, "code": "RU"},
    "japan": {"lat": 36.0, "lon": 138.0, "code": "JP"},
    "germany": {"lat": 51.0, "lon": 9.0, "code": "DE"},
    "france": {"lat": 46.0, "lon": 2.0, "code": "FR"},
    "united kingdom": {"lat": 54.0, "lon": -2.0, "code": "GB"},
    "uk": {"lat": 54.0, "lon": -2.0, "code": "GB"},
    "india": {"lat": 20.0, "lon": 77.0, "code": "IN"},
    "brazil": {"lat": -10.0, "lon": -55.0, "code": "BR"},
    "australia": {"lat": -25.0, "lon": 135.0, "code": "AU"},
    "canada": {"lat": 56.0, "lon": -106.0, "code": "CA"},
    "south korea": {"lat": 37.0, "lon": 127.0, "code": "KR"},
    "korea": {"lat": 37.0, "lon": 127.0, "code": "KR"},
    "italy": {"lat": 42.0, "lon": 12.0, "code": "IT"},
    "spain": {"lat": 40.0, "lon": -4.0, "code": "ES"},
    "mexico": {"lat": 23.0, "lon": -102.0, "code": "MX"},
    "indonesia": {"lat": -5.0, "lon": 120.0, "code": "ID"},
    "turkey": {"lat": 39.0, "lon": 35.0, "code": "TR"},
    "saudi arabia": {"lat": 25.0, "lon": 45.0, "code": "SA"},
    "iran": {"lat": 32.0, "lon": 53.0, "code": "IR"},
    "israel": {"lat": 31.0, "lon": 35.0, "code": "IL"},
    "palestine": {"lat": 31.0, "lon": 35.0, "code": "PS"},
    "gaza": {"lat": 31.0, "lon": 34.0, "code": "PS"},
    "egypt": {"lat": 26.0, "lon": 30.0, "code": "EG"},
    "south africa": {"lat": -29.0, "lon": 24.0, "code": "ZA"},
    "nigeria": {"lat": 10.0, "lon": 8.0, "code": "NG"},
    "ukraine": {"lat": 49.0, "lon": 32.0, "code": "UA"},
    "poland": {"lat": 52.0, "lon": 20.0, "code": "PL"},
    "pakistan": {"lat": 30.0, "lon": 70.0, "code": "PK"},
    "iraq": {"lat": 33.0, "lon": 44.0, "code": "IQ"},
    "syria": {"lat": 35.0, "lon": 39.0, "code": "SY"},
    "uae": {"lat": 24.0, "lon": 54.0, "code": "AE"},
    "dubai": {"lat": 25.0, "lon": 55.0, "code": "AE"},
    "qatar": {"lat": 25.0, "lon": 51.0, "code": "QA"},
    "greece": {"lat": 39.0, "lon": 22.0, "code": "GR"},
    "thailand": {"lat": 15.0, "lon": 100.0, "code": "TH"},
    "vietnam": {"lat": 14.0, "lon": 108.0, "code": "VN"},
    "philippines": {"lat": 13.0, "lon": 122.0, "code": "PH"},
    "new zealand": {"lat": -41.0, "lon": 174.0, "code": "NZ"},
    "kenya": {"lat": -1.0, "lon": 38.0, "code": "KE"},
    "afghanistan": {"lat": 34.0, "lon": 66.0, "code": "AF"},
}

BREAKING_KEYWORDS = [
    "breaking", "urgent", "just in", "developing", "exclusive",
    "alert", "emergency", "crisis", "major", "critical",
    "explosion", "attack", "earthquake", "flood", "fire",
    "war", "invasion", "coup", "assassination", "death",
    "president", "minister", "election", "resign", "collapse",
    "crash", "disaster", "terrorist", "bombing", "shooting"
]

DRAMATIC_PREFIXES = {
    "breaking": "[ BREAKING ] ",
    "urgent": "[ URGENT ] ",
    "exclusive": "[ EXCLUSIVE ] ",
    "developing": "[ DEVELOPING ] ",
    "crisis": "[ CRISIS ] ",
    "war": "[ CONFLICT ] ",
    "attack": "[ ATTACK ] ",
    "earthquake": "[ EARTHQUAKE ] ",
    "flood": "[ FLOOD ] ",
    "fire": "[ FIRE ] ",
    "election": "[ ELECTION ] ",
    "president": "[ POLITICAL ] ",
    "death": "[ TRAGEDY ] ",
    "protest": "[ PROTEST ] ",
}


class NewsPriority(Enum):
    BREAKING = "BREAKING"
    HIGH = "HIGH"
    NORMAL = "NORMAL"
    LOW = "LOW"


@dataclass
class NewsArticle:
    id: str
    title: str
    summary: str
    content: str
    source: str
    source_url: str
    image_url: str
    published: datetime
    country: str
    country_code: str
    latitude: float
    longitude: float
    priority: NewsPriority
    category: str
    keywords: List[str]


@dataclass
class UserPreferences:
    watched_countries: List[str] = field(default_factory=list)
    categories: List[str] = field(default_factory=lambda: ["world"])
    breaking_only: bool = False
    update_interval: int = 30


class PreferencesRequest(BaseModel):
    watched_countries: List[str] = []
    categories: List[str] = ["world"]
    breaking_only: bool = False


# ============================================================================
#                         FASTAPI APPLICATION
# ============================================================================

app = FastAPI(title=SYSTEM_NAME, version=VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

news_cache: List[NewsArticle] = []
last_update: datetime = None
user_prefs = UserPreferences()

# ============================================================================
#                         NEWS ENGINE
# ============================================================================

class NewsEngine:
    def __init__(self):
        self.session = None
    
    async def initialize(self):
        if AIOHTTP_AVAILABLE:
            self.session = aiohttp.ClientSession()
        print(f"[{SYSTEM_NAME}] Engine initialized")
        print(f"[{SYSTEM_NAME}] Sources: {sum(len(v) for v in RSS_FEEDS.values())} RSS feeds")
    
    async def fetch_rss_feeds(self, categories: List[str]) -> List:
        all_entries = []
        for category in categories:
            feeds = RSS_FEEDS.get(category, [])
            for feed_url in feeds:
                try:
                    feed = feedparser.parse(feed_url)
                    feed_title = feed.feed.get("title", "Unknown")
                    for entry in feed.entries[:15]:
                        entry_dict = {
                            "_entry": entry,
                            "title": entry.get("title", ""),
                            "summary": entry.get("summary", ""),
                            "link": entry.get("link", ""),
                            "published": entry.get("published", ""),
                            "source": feed_title,
                            "category": category
                        }
                        all_entries.append(entry_dict)
                except Exception as e:
                    pass
        return all_entries
    
    def detect_country(self, text: str) -> Tuple[str, str, float, float]:
        text_lower = text.lower()
        for country, coords in COUNTRY_COORDS.items():
            if country in text_lower:
                return country.title(), coords["code"], coords["lat"], coords["lon"]
        for country, coords in COUNTRY_COORDS.items():
            words = country.split()
            for word in words:
                if len(word) > 4 and word in text_lower:
                    return country.title(), coords["code"], coords["lat"], coords["lon"]
        return "Global", "XX", 0.0, 0.0
    
    def detect_priority(self, title: str, summary: str) -> NewsPriority:
        text = (title + " " + summary).lower()
        for keyword in BREAKING_KEYWORDS[:15]:
            if keyword in text:
                return NewsPriority.BREAKING
        for keyword in BREAKING_KEYWORDS[15:]:
            if keyword in text:
                return NewsPriority.HIGH
        return NewsPriority.NORMAL
    
    def extract_keywords(self, text: str) -> List[str]:
        words = re.findall(r'\b[A-Z][a-z]+\b', text)
        stop_words = {"The", "This", "That", "New", "Says", "About", "After", "From", "With", "Over", "Into", "Before", "After", "During", "Between"}
        return [w for w in words if w not in stop_words and len(w) > 3][:6]
    
    def create_sensational_summary(self, title: str, content: str) -> str:
        content = re.sub(r'<[^>]+>', '', content)
        content = html.unescape(content).strip()
        sentences = re.split(r'[.!?]+', content)
        first_sentence = next((s.strip() for s in sentences if len(s.strip()) > 30), "")
        text_lower = (title + " " + content).lower()
        prefix = ""
        for keyword, pre in DRAMATIC_PREFIXES.items():
            if keyword in text_lower:
                prefix = pre
                break
        if first_sentence:
            summary = prefix + first_sentence[:200]
        elif content:
            summary = prefix + content[:200]
        else:
            summary = prefix + title
        if prefix and not summary.endswith(("!", "...", "?")):
            summary += "..."
        return summary
    
    def extract_image_from_entry(self, entry: Dict) -> str:
        if hasattr(entry, 'media_content') and entry.media_content:
            for media in entry.media_content:
                if isinstance(media, dict) and media.get('url'):
                    return media['url']
                elif isinstance(media, str):
                    return media
        if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
            for thumb in entry.media_thumbnail:
                if isinstance(thumb, dict) and thumb.get('url'):
                    return thumb['url']
                elif isinstance(thumb, str):
                    return thumb
        if hasattr(entry, 'enclosures') and entry.enclosures:
            for enc in entry.enclosures:
                if isinstance(enc, dict):
                    url = enc.get('href', '')
                    type_ = enc.get('type', '')
                    if url and ('image' in type_ or any(ext in url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp'])):
                        return url
        summary = entry.get('summary', '') or entry.get('content', '') or entry.get('description', '')
        if summary:
            img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', summary, re.IGNORECASE)
            if img_match:
                return img_match.group(1)
        return ""
    
    async def process_entry(self, entry: Dict) -> Optional[NewsArticle]:
        try:
            title = entry.get("title", "")
            summary = entry.get("summary", "")
            if not title or len(title) < 10:
                return None
            full_text = title + " " + summary
            country, code, lat, lon = self.detect_country(full_text)
            priority = self.detect_priority(title, summary)
            keywords = self.extract_keywords(full_text)
            sensational_summary = self.create_sensational_summary(title, summary)
            raw_entry = entry.get("_entry", entry)
            image_url = self.extract_image_from_entry(raw_entry)
            published_str = entry.get("published", "")
            try:
                parsed_date = feedparser._parse_date(published_str)
                published = datetime(*parsed_date[:6]) if parsed_date else datetime.now()
            except:
                published = datetime.now()
            return NewsArticle(
                id=hashlib.md5(f"{title}{published}".encode()).hexdigest()[:8],
                title=title,
                summary=sensational_summary,
                content=summary,
                source=entry.get("source", "Unknown"),
                source_url=entry.get("link", ""),
                image_url=image_url,
                published=published,
                country=country,
                country_code=code,
                latitude=lat,
                longitude=lon,
                priority=priority,
                category=entry.get("category", "world"),
                keywords=keywords
            )
        except Exception as e:
            return None
    
    async def update_news(self) -> List[NewsArticle]:
        global news_cache, last_update
        categories = user_prefs.categories if user_prefs.categories else ["world"]
        entries = await self.fetch_rss_feeds(categories)
        articles = []
        for entry in entries:
            article = await self.process_entry(entry)
            if article:
                articles.append(article)
        articles.sort(key=lambda x: (
            0 if x.priority == NewsPriority.BREAKING else 1 if x.priority == NewsPriority.HIGH else 2,
            -x.published.timestamp()
        ))
        news_cache = articles[:100]
        last_update = datetime.now()
        return news_cache


news_engine = NewsEngine()


async def periodic_news_update():
    while True:
        try:
            await news_engine.update_news()
            print(f"[{datetime.now()}] Updated: {len(news_cache)} articles")
        except Exception as e:
            print(f"[Error] {e}")
        await asyncio.sleep(user_prefs.update_interval)


# ============================================================================
#                         API ENDPOINTS
# ============================================================================

@app.on_event("startup")
async def startup_event():
    print(f"\n{'='*60}")
    print(f"    {SYSTEM_NAME}")
    print(f"    {SUBTITLE}")
    print(f"{'='*60}\n")
    await news_engine.initialize()
    await news_engine.update_news()
    asyncio.create_task(periodic_news_update())


@app.get("/")
async def root():
    return {
        "name": SYSTEM_NAME,
        "version": VERSION,
        "status": "ONLINE",
        "articles": len(news_cache),
        "sources": sum(len(v) for v in RSS_FEEDS.values())
    }


@app.get("/api/news")
async def get_news(limit: int = 50, country: str = None, priority: str = None):
    articles = news_cache
    if country:
        articles = [a for a in articles if a.country.lower() == country.lower()]
    if priority:
        articles = [a for a in articles if a.priority.value == priority.upper()]
    if user_prefs.watched_countries:
        watched_lower = [c.lower() for c in user_prefs.watched_countries]
        articles = [a for a in articles if a.country.lower() in watched_lower or a.country == "Global"]
    if user_prefs.breaking_only:
        articles = [a for a in articles if a.priority == NewsPriority.BREAKING]
    return {
        "success": True,
        "count": len(articles[:limit]),
        "last_update": last_update.isoformat() if last_update else None,
        "articles": [
            {
                "id": a.id,
                "title": a.title,
                "summary": a.summary,
                "source": a.source,
                "image_url": a.image_url,
                "published": a.published.isoformat(),
                "country": a.country,
                "country_code": a.country_code,
                "latitude": a.latitude,
                "longitude": a.longitude,
                "priority": a.priority.value,
                "category": a.category,
                "keywords": a.keywords
            }
            for a in articles[:limit]
        ]
    }


@app.get("/api/breaking")
async def get_breaking():
    breaking = [a for a in news_cache if a.priority == NewsPriority.BREAKING]
    return {
        "success": True,
        "count": len(breaking),
        "articles": [
            {
                "id": a.id,
                "title": a.title,
                "summary": a.summary,
                "source": a.source,
                "image_url": a.image_url,
                "published": a.published.isoformat(),
                "country": a.country,
                "latitude": a.latitude,
                "longitude": a.longitude
            }
            for a in breaking[:20]
        ]
    }


@app.get("/api/countries")
async def get_countries():
    seen = set()
    unique = []
    for k, v in COUNTRY_COORDS.items():
        if v["code"] not in seen:
            seen.add(v["code"])
            unique.append({"name": k.title(), "code": v["code"], "lat": v["lat"], "lon": v["lon"]})
    return {"countries": sorted(unique, key=lambda x: x["name"])}


@app.get("/api/categories")
async def get_categories():
    return {"categories": [{"id": k, "name": k.title()} for k in RSS_FEEDS.keys()]}


@app.post("/api/preferences")
async def set_preferences(prefs: PreferencesRequest):
    global user_prefs
    user_prefs.watched_countries = prefs.watched_countries
    user_prefs.categories = prefs.categories
    user_prefs.breaking_only = prefs.breaking_only
    return {
        "success": True,
        "preferences": {
            "watched_countries": user_prefs.watched_countries,
            "categories": user_prefs.categories,
            "breaking_only": user_prefs.breaking_only
        }
    }


@app.get("/api/preferences")
async def get_preferences():
    return {
        "watched_countries": user_prefs.watched_countries,
        "categories": user_prefs.categories,
        "breaking_only": user_prefs.breaking_only,
        "update_interval": user_prefs.update_interval
    }


@app.post("/api/refresh")
async def refresh_news():
    await news_engine.update_news()
    return {"success": True, "articles": len(news_cache)}


@app.get("/api/stats")
async def get_stats():
    return {
        "total_articles": len(news_cache),
        "breaking": sum(1 for a in news_cache if a.priority == NewsPriority.BREAKING),
        "countries": len(set(a.country for a in news_cache if a.country != "Global")),
        "last_update": last_update.isoformat() if last_update else None
    }


@app.get("/health")
async def health():
    return {"status": "healthy", "sources": sum(len(v) for v in RSS_FEEDS.values())}


@app.get("/download/backend")
async def download_backend():
    return FileResponse(
        path=os.path.abspath(__file__),
        filename="global_neydra_news.py",
        media_type="text/x-python"
    )


@app.get("/download/frontend")
async def download_frontend():
    html_path = os.path.join(os.path.dirname(__file__), "global_neydra_news.html")
    if os.path.exists(html_path):
        return FileResponse(
            path=html_path,
            filename="global_neydra_news.html",
            media_type="text/html"
        )
    raise HTTPException(status_code=404, detail="Frontend file not found")


if __name__ == "__main__":
    print(f"\n{'='*60}")
    print(f"    Starting {SYSTEM_NAME}")
    print(f"    pip install fastapi uvicorn feedparser aiohttp")
    print(f"    python global_neydra_news.py")
    print(f"{'='*60}\n")
    
    print("╔════════════════════════════════════════════════════════╗")
    print("║           LOCALTUNNEL CONNECTION GUIDE                 ║")
    print("╠════════════════════════════════════════════════════════╣")
    print("║ 1. Open a NEW terminal window.                         ║")
    print("║ 2. Run: npx localtunnel --port 8000                   ║")
    print("║ 3. Copy the 'your url is: https://xx-xx-xx.loca.lt'    ║")
    print("║ 4. Paste that URL into the HTML Dashboard prompt.      ║")
    print("╚════════════════════════════════════════════════════════╝")
    print("\n[INFO] Starting API Server on port 8000...\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")